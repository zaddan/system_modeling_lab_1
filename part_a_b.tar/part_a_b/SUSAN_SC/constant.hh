#define BP_CONST 516 //migh have to modify later
#define X_SIZE_CONST 76
#define Y_SIZE_CONST 95
#define IMAGE_SIZE X_SIZE_CONST*Y_SIZE_CONST
#define FILE_NAME_SIZE 100 
#define MAX_NO_EDGES 2650
//typedef const unsigned long size
